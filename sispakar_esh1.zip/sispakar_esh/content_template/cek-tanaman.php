

            <header class="bg-blue py-5">
                <div class="container px-5">
                
                    <div class="row gx-2 bg-blue align-items-center justify-content-center">
                    <h3>Silahkan pilih : </h3>
                    <select class="form-select" aria-label="Default select example">
                    <option selected>Pilih Salah Satu</option>
                    <option value="1">Bawang Daun</option>
                    <option value="2">Kubis / Kol</option>
                    <option value="3">Bawang Merah</option>
                    </select>   
                    </div>  
                    <br> 
                     
                </div>
                </header>


<!-- Daftar Pertanyaan -->

<!--- Perintah Periksa Hama -->
<br>
<div class="container px-5">               
<a class="btn btn-success" href="<?php echo site_url('#') ?>">Periksa</a> <a class="btn btn-danger" href="<?php echo site_url('#') ?>">Ulang</a>
</div>
<br>



</main>
