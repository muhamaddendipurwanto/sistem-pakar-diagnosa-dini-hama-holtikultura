  <!-- Footer-->
  <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white"><p class="footer">#DigitalAgriculture  Page rendered in <strong>{elapsed_time}</strong> seconds. <br> Rancang Bangun Sistem Pakar Menggunakan Certainy Faktor Untuk Diagnosa Dini Hama Pada Holtikultura - ESH 2021 </p></div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>                    
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="asset/js/scripts.js"></script>
        <script src="http://code.jquery.com/jquery-latest.js" type="text/javascript"></script>
       
       
    </body>
</html>

	
